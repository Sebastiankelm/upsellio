<?php
if (!defined("ABSPATH")) {
    exit;
}

function upsellio_lead_magnet_seed_build_content($item)
{
    $includes = "";
    foreach ((array) ($item["includes"] ?? []) as $include) {
        $includes .= "<li>" . esc_html((string) $include) . "</li>";
    }

    $for_whom = "";
    foreach ((array) ($item["for_whom"] ?? []) as $person) {
        $for_whom .= "<li>" . esc_html((string) $person) . "</li>";
    }

    $title = esc_html((string) ($item["title"] ?? ""));
    $problem = esc_html((string) ($item["problem"] ?? ""));
    $outcome = esc_html((string) ($item["outcome"] ?? ""));
    $keyword = esc_html((string) ($item["keyword"] ?? ""));

    return <<<HTML
<h2>Co znajdziesz w materiale: {$title}</h2>
<p>{$problem}</p>

<h2>Co zawiera materiał</h2>
<ul>
{$includes}
</ul>

<h2>Dla kogo jest ten lead magnet</h2>
<ul>
{$for_whom}
</ul>

<h2>Jak wykorzystać materiał w praktyce</h2>
<p>{$outcome}</p>

<h2>Dlaczego warto pobrać ten materiał</h2>
<p>Materiał pomaga uporządkować decyzje marketingowe i sprzedażowe wokół tematu <strong>{$keyword}</strong>. Zamiast zgadywać, możesz przejść przez konkretne pytania, checklisty i kryteria oceny, które pokazują, co poprawić jako pierwsze.</p>
HTML;
}

function upsellio_get_seeded_lead_magnets()
{
    return [
        [
            "slug" => "checklista-meta-ads-b2b",
            "title" => "Checklista Meta Ads B2B przed uruchomieniem kampanii",
            "excerpt" => "Lista kontrolna dla firm B2B, które chcą sprawdzić ofertę, landing page, tracking i jakość leadów przed startem kampanii Meta Ads.",
            "category" => "Meta Ads",
            "category_slug" => "meta-ads",
            "type" => "Checklista",
            "meta" => "PDF · 12 punktów · 7 min",
            "badge" => "Najczęściej pobierany",
            "cta" => "Pobierz checklistę",
            "image" => "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1600&q=80",
            "keyword" => "checklista Meta Ads B2B",
            "problem" => "Kampanie Meta Ads często startują zbyt szybko: bez jasnej oferty, bez poprawnego trackingu i bez kryteriów oceny jakości leadów. Ta checklista pomaga wychwycić błędy zanim budżet zacznie się przepalać.",
            "outcome" => "Przejdź przez punkty przed startem kampanii, zaznacz braki i popraw elementy, które bezpośrednio wpływają na koszt oraz jakość zapytań.",
            "includes" => ["Ocena oferty i komunikatu reklamowego", "Sprawdzenie formularza i landing page", "Lista podstawowych zdarzeń do trackingu", "Kryteria oceny leadów po stronie sprzedaży"],
            "for_whom" => ["Właściciele firm B2B", "Marketing managerowie", "Firmy planujące kampanie Meta Ads", "Zespoły, które mają ruch, ale słabe leady"],
            "is_featured" => true,
        ],
        [
            "slug" => "audyt-google-ads-checklista",
            "title" => "Mini audyt Google Ads: 21 pytań do konta reklamowego",
            "excerpt" => "Praktyczny audyt konta Google Ads, który pomaga znaleźć przepalony budżet, słabe słowa kluczowe i problemy z konwersją.",
            "category" => "Google Ads",
            "category_slug" => "google-ads",
            "type" => "Audyt",
            "meta" => "PDF · 21 pytań · 10 min",
            "badge" => "Audyt konta",
            "cta" => "Pobierz audyt",
            "image" => "https://images.unsplash.com/photo-1551281044-8b5bd6fddf8f?auto=format&fit=crop&w=1600&q=80",
            "keyword" => "audyt Google Ads",
            "problem" => "W Google Ads problemem często nie jest sam budżet, tylko jego struktura: zbyt szerokie dopasowania, brak wykluczeń, słabe strony docelowe i niewłaściwe konwersje.",
            "outcome" => "Użyj listy pytań do szybkiej diagnozy konta. Jeśli kilka odpowiedzi wskazuje ryzyko, masz jasną kolejność działań naprawczych.",
            "includes" => ["Pytania o strukturę kampanii", "Kontrola konwersji i trackingów", "Ocena intencji słów kluczowych", "Wskazówki do ograniczenia strat budżetu"],
            "for_whom" => ["Firmy prowadzące Google Ads", "E-commerce i usługi B2B", "Osoby przejmujące konto po agencji", "Zespoły z rosnącym kosztem konwersji"],
            "is_featured" => false,
        ],
        [
            "slug" => "szablon-landing-page-b2b",
            "title" => "Szablon landing page B2B pod pozyskiwanie klientów",
            "excerpt" => "Struktura landing page dla firm B2B: hero, argumenty sprzedażowe, dowody, formularz i sekcje, które pomagają zwiększyć konwersję.",
            "category" => "Landing page",
            "category_slug" => "landing-page",
            "type" => "Szablon",
            "meta" => "PDF · Struktura strony · 9 min",
            "badge" => "Pod konwersję",
            "cta" => "Pobierz szablon",
            "image" => "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80",
            "keyword" => "landing page B2B pod pozyskiwanie klientów",
            "problem" => "Wiele landing page wygląda dobrze, ale nie prowadzi użytkownika do decyzji. Brakuje jasnej obietnicy, dowodów, redukcji ryzyka i logicznego formularza.",
            "outcome" => "Potraktuj szablon jak mapę sekcji. Uzupełnij ją własną ofertą, argumentami i przykładami, a potem przetestuj na kampaniach płatnych lub ruchu organicznym.",
            "includes" => ["Układ sekcji landing page", "Lista elementów zwiększających zaufanie", "Sugestie CTA i formularzy", "Pytania do dopracowania komunikatu"],
            "for_whom" => ["Firmy usługowe B2B", "SaaS i konsulting", "Zespoły planujące kampanie Ads", "Firmy z niską konwersją formularza"],
            "is_featured" => false,
        ],
        [
            "slug" => "kalkulator-jakosci-leadow",
            "title" => "Kalkulator jakości leadów dla kampanii B2B",
            "excerpt" => "Prosty arkusz oceny leadów, który pomaga odróżnić zapytania przypadkowe od kontaktów z realnym potencjałem sprzedażowym.",
            "category" => "Lead generation",
            "category_slug" => "lead-generation",
            "type" => "Arkusz",
            "meta" => "XLSX · Scoring leadów · 8 min",
            "badge" => "Scoring",
            "cta" => "Pobierz kalkulator",
            "image" => "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1600&q=80",
            "keyword" => "kalkulator jakości leadów B2B",
            "problem" => "Sam koszt leada nie wystarcza do oceny kampanii. Tani lead może nie mieć budżetu, decyzyjności ani realnej potrzeby, dlatego warto mierzyć jakość po stronie sprzedaży.",
            "outcome" => "Wprowadź leady z kampanii i oceń je według kilku kryteriów. Po kilku tygodniach zobaczysz, które źródła generują wartościowy pipeline.",
            "includes" => ["Prosty scoring leadów", "Kryteria budżetu i decyzyjności", "Ocena dopasowania do oferty", "Podsumowanie źródeł leadów"],
            "for_whom" => ["Firmy B2B z działem sprzedaży", "Zespoły łączące marketing i sprzedaż", "Firmy mierzące CPL, ale nie jakość", "Właściciele analizujący ROI kampanii"],
            "is_featured" => false,
        ],
        [
            "slug" => "brief-strony-internetowej",
            "title" => "Brief strony internetowej, która ma sprzedawać",
            "excerpt" => "Zestaw pytań do zaplanowania strony firmowej, landing page lub sklepu tak, żeby od początku wspierały sprzedaż i SEO.",
            "category" => "Strony WWW",
            "category_slug" => "strony-www",
            "type" => "Brief",
            "meta" => "DOC/PDF · 18 pytań · 12 min",
            "badge" => "Plan strony",
            "cta" => "Pobierz brief",
            "image" => "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=1600&q=80",
            "keyword" => "brief strony internetowej pod sprzedaż",
            "problem" => "Strony internetowe często powstają od wyglądu, a nie od decyzji zakupowej klienta. Brief pomaga zacząć od oferty, procesu sprzedaży, SEO i konwersji.",
            "outcome" => "Wypełnij brief przed rozmową o stronie. Dzięki temu szybciej określisz zakres, priorytety treści i elementy, które mają pracować na zapytania.",
            "includes" => ["Pytania o ofertę i grupę docelową", "Sekcje strony pod konwersję", "Wymagania SEO i techniczne", "Lista materiałów potrzebnych do wdrożenia"],
            "for_whom" => ["Firmy planujące nową stronę", "Właściciele przebudowujący ofertę", "Marketerzy przygotowujący landing page", "Firmy usługowe i e-commerce"],
            "is_featured" => false,
        ],
        [
            "slug" => "plan-90-dni-marketing-b2b",
            "title" => "Plan 90 dni marketingu B2B",
            "excerpt" => "Plan działań na pierwszy kwartał: diagnoza, strona, kampanie, mierzenie jakości leadów i iteracje sprzedażowe.",
            "category" => "Strategia",
            "category_slug" => "strategia",
            "type" => "Plan działania",
            "meta" => "PDF · 90 dni · 11 min",
            "badge" => "Strategia",
            "cta" => "Pobierz plan",
            "image" => "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1600&q=80",
            "keyword" => "plan marketingu B2B na 90 dni",
            "problem" => "Bez planu marketing zamienia się w listę losowych działań: posty, reklamy, poprawki strony i raporty bez jasnego priorytetu.",
            "outcome" => "Użyj planu jako ramy na kwartał. Najpierw uporządkuj fundamenty, potem uruchom testy, a następnie oceniaj wynik na podstawie jakości leadów.",
            "includes" => ["Etap diagnozy i priorytetów", "Plan pracy nad stroną i ofertą", "Kalendarz testów kampanii", "Metryki do cotygodniowej oceny"],
            "for_whom" => ["Właściciele firm B2B", "Marketing managerowie", "Firmy przed startem kampanii", "Zespoły porządkujące działania sprzedażowe"],
            "is_featured" => false,
        ],
    ];
}

function upsellio_seed_lead_magnets($force = false)
{
    if (!post_type_exists("lead_magnet")) {
        return ["created" => 0, "updated" => 0, "message" => "lead_magnet_post_type_missing"];
    }

    $items = upsellio_get_seeded_lead_magnets();
    $created = 0;
    $updated = 0;

    foreach ($items as $index => $item) {
        $slug = sanitize_title((string) ($item["slug"] ?? ""));
        if ($slug === "") {
            continue;
        }

        $existing_post = get_page_by_path($slug, OBJECT, "lead_magnet");
        $post_data = [
            "post_type" => "lead_magnet",
            "post_status" => "publish",
            "post_title" => (string) ($item["title"] ?? ""),
            "post_name" => $slug,
            "post_excerpt" => (string) ($item["excerpt"] ?? ""),
            "post_content" => upsellio_lead_magnet_seed_build_content($item),
            "menu_order" => $index,
        ];

        if ($existing_post instanceof WP_Post) {
            if (!$force) {
                continue;
            }
            $post_data["ID"] = (int) $existing_post->ID;
            $post_id = wp_update_post($post_data, true);
            if (is_wp_error($post_id) || (int) $post_id <= 0) {
                continue;
            }
            $updated++;
        } else {
            $post_id = wp_insert_post($post_data, true);
            if (is_wp_error($post_id) || (int) $post_id <= 0) {
                continue;
            }
            $created++;
        }

        $term_name = (string) ($item["category"] ?? "Lead generation");
        $term_slug = sanitize_title((string) ($item["category_slug"] ?? $term_name));
        $term = term_exists($term_slug, "lead_magnet_category");
        if (!$term) {
            $term = wp_insert_term($term_name, "lead_magnet_category", ["slug" => $term_slug]);
        }
        if (!is_wp_error($term)) {
            $term_id = (int) (is_array($term) ? ($term["term_id"] ?? 0) : 0);
            if ($term_id > 0) {
                wp_set_object_terms((int) $post_id, [$term_id], "lead_magnet_category");
            }
        }

        update_post_meta((int) $post_id, "_ups_lm_type", (string) ($item["type"] ?? ""));
        update_post_meta((int) $post_id, "_ups_lm_meta", (string) ($item["meta"] ?? ""));
        update_post_meta((int) $post_id, "_ups_lm_badge", (string) ($item["badge"] ?? ""));
        update_post_meta((int) $post_id, "_ups_lm_cta", (string) ($item["cta"] ?? ""));
        update_post_meta((int) $post_id, "_ups_lm_image", esc_url_raw((string) ($item["image"] ?? "")));
        update_post_meta((int) $post_id, "_ups_lm_featured", !empty($item["is_featured"]) ? "1" : "0");
        update_post_meta((int) $post_id, "_upsellio_is_lead_magnet", "1");
    }

    return ["created" => $created, "updated" => $updated, "message" => "ok"];
}

function upsellio_get_lead_magnet_seed_url($force = false)
{
    return add_query_arg([
        "upsellio_seed_lead_magnets" => 1,
        "force" => $force ? 1 : 0,
        "_upsellio_nonce" => wp_create_nonce("upsellio_seed_lead_magnets"),
    ], admin_url("edit.php?post_type=lead_magnet&page=upsellio-lead-magnet-seed"));
}

function upsellio_handle_lead_magnet_seed_request()
{
    if (!is_admin() || !current_user_can("manage_options")) {
        return;
    }
    if (!isset($_GET["upsellio_seed_lead_magnets"])) {
        return;
    }

    $nonce = isset($_GET["_upsellio_nonce"]) ? sanitize_text_field(wp_unslash($_GET["_upsellio_nonce"])) : "";
    if (!wp_verify_nonce($nonce, "upsellio_seed_lead_magnets")) {
        return;
    }

    $force = isset($_GET["force"]) && (int) $_GET["force"] === 1;
    $result = upsellio_seed_lead_magnets($force);
    update_option("upsellio_lead_magnet_seed_v1_done", "1");

    $redirect_url = add_query_arg([
        "upsellio_lead_magnet_seed_done" => 1,
        "created" => (int) ($result["created"] ?? 0),
        "updated" => (int) ($result["updated"] ?? 0),
        "msg" => (string) ($result["message"] ?? "ok"),
    ], admin_url("edit.php?post_type=lead_magnet&page=upsellio-lead-magnet-seed"));
    wp_safe_redirect($redirect_url);
    exit;
}
add_action("admin_init", "upsellio_handle_lead_magnet_seed_request");

function upsellio_register_lead_magnet_seed_menu()
{
    if (!post_type_exists("lead_magnet")) {
        return;
    }

    add_submenu_page(
        "edit.php?post_type=lead_magnet",
        "Generator lead magnetów",
        "Generator materiałów",
        "manage_options",
        "upsellio-lead-magnet-seed",
        "upsellio_lead_magnet_seed_screen",
        32
    );
}
add_action("admin_menu", "upsellio_register_lead_magnet_seed_menu");

function upsellio_lead_magnet_seed_screen()
{
    if (!current_user_can("manage_options")) {
        return;
    }
    ?>
    <div class="wrap">
      <h1>Generator lead magnetów</h1>
      <p>Tworzy gotowe materiały w typie treści <code>lead_magnet</code>. Po wygenerowaniu pojawią się automatycznie na podstronie materiałów.</p>
      <p><a class="button button-primary" href="<?php echo esc_url(upsellio_get_lead_magnet_seed_url(false)); ?>">Wgraj brakujące materiały do bazy</a></p>
      <p><a class="button" href="<?php echo esc_url(upsellio_get_lead_magnet_seed_url(true)); ?>">Nadpisz i odśwież wszystkie materiały</a></p>
    </div>
    <?php
}

function upsellio_lead_magnet_seed_notice()
{
    if (!is_admin() || !isset($_GET["upsellio_lead_magnet_seed_done"])) {
        return;
    }

    $created = isset($_GET["created"]) ? (int) $_GET["created"] : 0;
    $updated = isset($_GET["updated"]) ? (int) $_GET["updated"] : 0;
    $msg = isset($_GET["msg"]) ? sanitize_text_field(wp_unslash($_GET["msg"])) : "ok";
    if ($msg !== "ok") {
        echo '<div class="notice notice-error"><p>Nie udało się wygenerować lead magnetów.</p></div>';
        return;
    }

    echo '<div class="notice notice-success"><p>';
    echo esc_html("Lead magnety zaktualizowane. Utworzono: {$created}, zaktualizowano: {$updated}.");
    echo "</p></div>";
}
add_action("admin_notices", "upsellio_lead_magnet_seed_notice");
