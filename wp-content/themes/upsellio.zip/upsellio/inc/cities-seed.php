<?php

if (!defined("ABSPATH")) {
    exit;
}

function upsellio_register_city_post_type()
{
    register_post_type("miasto", [
        "labels" => [
            "name" => "Miasta",
            "singular_name" => "Miasto",
            "add_new_item" => "Dodaj podstrone miasta",
            "edit_item" => "Edytuj podstrone miasta",
        ],
        "public" => true,
        "has_archive" => "miasta",
        "rewrite" => [
            "slug" => "miasto",
            "with_front" => false,
        ],
        "menu_icon" => "dashicons-location-alt",
        "supports" => ["title", "editor", "excerpt", "thumbnail", "custom-fields"],
        "show_in_rest" => true,
        "publicly_queryable" => true,
        "exclude_from_search" => false,
    ]);
}
add_action("init", "upsellio_register_city_post_type");

function upsellio_city_document_title($parts)
{
    if (!is_singular("miasto")) {
        return $parts;
    }

    $city = get_post_meta(get_the_ID(), "_upsellio_city_name", true);
    $parts["title"] = "Marketing i strony WWW " . $city;
    $parts["tagline"] = "Upsellio";

    return $parts;
}
add_filter("document_title_parts", "upsellio_city_document_title");

function upsellio_city_meta_tags()
{
    if (!is_singular("miasto")) {
        return;
    }

    $postId = get_the_ID();
    $city = get_post_meta($postId, "_upsellio_city_name", true);
    $description = get_post_meta($postId, "_upsellio_city_meta_description", true);
    $url = get_permalink($postId);

    if (!$description) {
        $description = "Pozyskuj wiecej klientow w miescie " . $city . " dzieki kampaniom Meta i Google Ads oraz stronie WWW nastawionej na konwersje.";
    }

    echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
    echo '<meta name="robots" content="index,follow,max-snippet:-1,max-image-preview:large,max-video-preview:-1">' . "\n";
    echo '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:type" content="article">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr("Marketing i strony WWW " . $city . " | Upsellio") . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($description) . '">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "ProfessionalService",
        "name" => "Upsellio",
        "areaServed" => [
            "@type" => "City",
            "name" => $city,
        ],
        "url" => $url,
        "description" => $description,
    ];
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
}
add_action("wp_head", "upsellio_city_meta_tags", 5);

function upsellio_get_city_nearby_links($currentSlug, $limit = 6)
{
    $cities = upsellio_get_cities_dataset();
    $currentIndex = 0;

    foreach ($cities as $index => $city) {
        if ($city["slug"] === $currentSlug) {
            $currentIndex = $index;
            break;
        }
    }

    $links = [];
    for ($i = 1; $i <= $limit; $i++) {
        $nextIndex = ($currentIndex + $i) % count($cities);
        $nextCity = $cities[$nextIndex];
        $links[] = [
            "name" => $nextCity["name"],
            "url" => home_url("/miasto/" . $nextCity["slug"] . "/"),
        ];
    }

    return $links;
}

function upsellio_get_footer_city_links_html()
{
    $posts = get_posts([
        "post_type" => "miasto",
        "post_status" => "publish",
        "numberposts" => 200,
        "orderby" => "title",
        "order" => "ASC",
        "fields" => "ids",
    ]);

    if (empty($posts)) {
        $cityLinks = array_map(function ($city) {
            return [
                "name" => $city["name"],
                "url" => home_url("/miasto/" . $city["slug"] . "/"),
            ];
        }, upsellio_get_cities_dataset());
    } else {
        $cityLinks = array_map(function ($postId) {
            return [
                "name" => get_post_meta($postId, "_upsellio_city_name", true) ?: get_the_title($postId),
                "url" => get_permalink($postId),
            ];
        }, $posts);
    }

    $chunks = array_chunk($cityLinks, 50);
    ob_start();
    ?>
    <section class="upsellio-local-seo" aria-label="Miasta obslugi">
      <style>
        .upsellio-local-seo{margin-top:32px;padding-top:24px;border-top:1px solid var(--border,#e6e6e1)}
        .upsellio-local-seo-title{font-size:13px;font-weight:700;letter-spacing:.3px;margin-bottom:14px;color:var(--text-2,#3d3d38)}
        .upsellio-local-seo-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px 18px}
        .upsellio-local-seo-link{font-size:13px;line-height:1.5;color:var(--text-3,#7c7c74);display:inline-block}
        .upsellio-local-seo-link:hover{color:var(--teal,#1d9e75)}
        @media(max-width:860px){.upsellio-local-seo-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
      </style>
      <div class="upsellio-local-seo-title">Marketing i strony WWW - 200 najwiekszych miast w Polsce</div>
      <?php foreach ($chunks as $chunk) : ?>
        <div class="upsellio-local-seo-grid">
          <?php foreach ($chunk as $item) : ?>
            <a class="upsellio-local-seo-link" href="<?php echo esc_url($item["url"]); ?>">
              <?php echo esc_html("Marketing i strony WWW " . $item["name"]); ?>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </section>
    <?php

    return ob_get_clean();
}

function upsellio_generate_city_content($city, $position)
{
    $name = $city["name"];
    $voivodeship = $city["voivodeship"];
    $marketAngle = $city["market_angle"];
    $serviceFocus = $city["service_focus"];

    $leadVariants = [
        "Pomagam firmom z miasta %s budowac przewidywalny doplyw klientow przez kampanie reklamowe i strony, ktore konwertuja.",
        "Jesli Twoja firma dziala w miescie %s, laczymy performance marketing z mocnym komunikatem oferty i strony WWW.",
        "W miescie %s wdrazamy podejscie nastawione na wynik: wiecej leadow, lepsza jakosc zapytan i wyzsza skutecznosc sprzedazy.",
        "Dla firm z miasta %s projektujemy kampanie i strony tak, aby realnie wspieraly cele sprzedazowe, a nie tylko statystyki.",
    ];
    $lead = sprintf($leadVariants[$position % count($leadVariants)], $name);

    $marketVariants = [
        "W %s widac duza konkurencje o uwage klienta, dlatego kluczowe jest rozroznienie oferty i precyzyjne prowadzenie ruchu.",
        "Rynek %s wymaga stalej optymalizacji kosztu zapytania oraz czytelnej komunikacji wartosci uslugi.",
        "W regionie %s firmy wygrywaja wtedy, gdy reklama i strona sa spojne z realnym procesem handlowym.",
        "W miescie %s najczesciej traci sie wynik na etapie przejscia z reklamy na strone i domkniecia leada.",
    ];
    $marketSection = sprintf($marketVariants[($position + 1) % count($marketVariants)], $name);

    $serviceBullets = [
        "Strategia lokalna dla miasta " . $name . " oparta na danych i intencji klienta",
        "Kampanie Meta i Google Ads nastawione na jakosc zapytan, nie tylko ruch",
        "Strona WWW / landing page przygotowane pod konwersje i kolejne kroki sprzedazy",
        "Analityka i raportowanie pokazujace, ktore dzialania realnie daja przychod",
    ];

    $faq = [
        [
            "q" => "Czy obslugujesz firmy z miasta " . $name . " zdalnie czy lokalnie?",
            "a" => "Tak, obsluga moze odbywac sie w pelni zdalnie, a w razie potrzeby umawiamy spotkania robocze. Najwazniejsza jest skutecznosc dzialan i jasny proces wspolpracy.",
        ],
        [
            "q" => "Ile trwa uruchomienie kampanii dla firmy z " . $name . "?",
            "a" => "Najczesciej od 7 do 21 dni, zaleznie od gotowosci oferty, materialow i zakresu wdrozenia strony lub landing page.",
        ],
        [
            "q" => "Czy moge zlecic tylko strone WWW dla miasta " . $name . "?",
            "a" => "Tak. Mozesz zaczac od strony lub landing page, a kampanie uruchomic pozniej. W projekcie i tak dbamy o logike pozniejszej reklamy.",
        ],
        [
            "q" => "Jak mierzysz efekty dzialan SEO lokalnego i kampanii?",
            "a" => "Wspolnie ustalamy KPI: liczba i jakosc leadow, koszt pozyskania, konwersja na stronie, wartosc zapytan i udzial ruchu lokalnego.",
        ],
    ];

    $cta = "Chcesz sprawdzic, jak podniesc wyniki marketingu i strony WWW w miescie " . $name . "? Umow bezplatna rozmowe i dostan plan dzialan.";

    $metaDescription = "Marketing i strony WWW " . $name . ": Meta Ads, Google Ads, strony nastawione na konwersje i wsparcie sprzedazy dla firm z woj. " . $voivodeship . ".";

    $content = '<h2>Marketing i strony WWW ' . esc_html($name) . '</h2>';
    $content .= '<p>' . esc_html($lead) . '</p>';
    $content .= '<h3>Jak wspieramy firmy lokalnie</h3>';
    $content .= '<p>' . esc_html($marketSection) . ' Specjalizacja: ' . esc_html($marketAngle) . '.</p>';
    $content .= '<p>Model wspolpracy: ' . esc_html($serviceFocus) . '.</p>';
    $content .= '<h3>Zakres wspolpracy</h3><ul>';
    foreach ($serviceBullets as $bullet) {
        $content .= '<li>' . esc_html($bullet) . '</li>';
    }
    $content .= '</ul>';
    $content .= '<h3>FAQ lokalne</h3>';
    foreach ($faq as $item) {
        $content .= '<p><strong>' . esc_html($item["q"]) . '</strong><br>' . esc_html($item["a"]) . '</p>';
    }
    $content .= '<p><strong>' . esc_html($cta) . '</strong></p>';

    $fingerprint = md5($lead . "|" . $marketSection . "|" . $serviceFocus . "|" . $marketAngle);

    return [
        "title" => "Marketing i strony WWW " . $name,
        "excerpt" => $lead,
        "meta_description" => $metaDescription,
        "content" => $content,
        "faq" => $faq,
        "cta" => $cta,
        "fingerprint" => $fingerprint,
    ];
}

function upsellio_seed_city_pages($force = false)
{
    $alreadySeeded = get_option("upsellio_cities_seeded_v1");
    if ($alreadySeeded && !$force) {
        return ["created" => 0, "updated" => 0, "skipped" => 200, "message" => "already_seeded"];
    }

    $fingerprints = [];
    $created = 0;
    $updated = 0;

    foreach (upsellio_get_cities_dataset() as $index => $city) {
        $generated = upsellio_generate_city_content($city, $index);
        if (isset($fingerprints[$generated["fingerprint"]])) {
            $generated["content"] .= "<p>Ta podstrona zawiera lokalne podejscie przygotowane indywidualnie dla miasta " . esc_html($city["name"]) . ".</p>";
            $generated["fingerprint"] = md5($generated["fingerprint"] . "|" . $city["slug"]);
        }
        $fingerprints[$generated["fingerprint"]] = true;

        $existing = get_page_by_path($city["slug"], OBJECT, "miasto");

        $postData = [
            "post_type" => "miasto",
            "post_status" => "publish",
            "post_title" => $generated["title"],
            "post_name" => $city["slug"],
            "post_excerpt" => $generated["excerpt"],
            "post_content" => $generated["content"],
        ];

        if ($existing) {
            $postData["ID"] = $existing->ID;
            $postId = wp_update_post($postData, true);
            if (!is_wp_error($postId)) {
                $updated++;
            }
        } else {
            $postId = wp_insert_post($postData, true);
            if (!is_wp_error($postId)) {
                $created++;
            }
        }

        if (is_wp_error($postId)) {
            continue;
        }

        update_post_meta($postId, "_upsellio_city_name", $city["name"]);
        update_post_meta($postId, "_upsellio_city_slug", $city["slug"]);
        update_post_meta($postId, "_upsellio_city_voivodeship", $city["voivodeship"]);
        update_post_meta($postId, "_upsellio_city_market_angle", $city["market_angle"]);
        update_post_meta($postId, "_upsellio_city_service_focus", $city["service_focus"]);
        update_post_meta($postId, "_upsellio_city_meta_description", $generated["meta_description"]);
        update_post_meta($postId, "_upsellio_city_faq", $generated["faq"]);
        update_post_meta($postId, "_upsellio_city_cta", $generated["cta"]);
        update_post_meta($postId, "_upsellio_city_fingerprint", $generated["fingerprint"]);
    }

    update_option("upsellio_cities_seeded_v1", current_time("mysql"));

    return ["created" => $created, "updated" => $updated, "skipped" => 0, "message" => "ok"];
}

function upsellio_seed_cities_if_requested()
{
    if (!is_admin() || !current_user_can("manage_options")) {
        return;
    }

    if (!isset($_GET["upsellio_seed_cities"])) {
        return;
    }

    $nonce = isset($_GET["_upsellio_nonce"]) ? sanitize_text_field(wp_unslash($_GET["_upsellio_nonce"])) : "";
    if (!wp_verify_nonce($nonce, "upsellio_seed_cities")) {
        return;
    }

    $force = !empty($_GET["force"]);
    $result = upsellio_seed_city_pages($force);

    $redirectUrl = add_query_arg([
        "upsellio_seed_done" => 1,
        "created" => (int) $result["created"],
        "updated" => (int) $result["updated"],
        "msg" => $result["message"],
    ], admin_url("edit.php?post_type=miasto"));
    wp_safe_redirect($redirectUrl);
    exit;
}
add_action("admin_init", "upsellio_seed_cities_if_requested");

function upsellio_seed_cities_admin_notice()
{
    if (!is_admin() || !isset($_GET["upsellio_seed_done"])) {
        return;
    }

    $created = isset($_GET["created"]) ? (int) $_GET["created"] : 0;
    $updated = isset($_GET["updated"]) ? (int) $_GET["updated"] : 0;
    $msg = isset($_GET["msg"]) ? sanitize_text_field(wp_unslash($_GET["msg"])) : "ok";

    echo '<div class="notice notice-success"><p>';
    if ($msg === "already_seeded") {
        echo esc_html("Generator miast byl juz uruchomiony. Dodaj parametr force=1, aby nadpisac.");
    } else {
        echo esc_html("Wygenerowano podstrony miast: utworzono {$created}, zaktualizowano {$updated}.");
    }
    echo "</p></div>";
}
add_action("admin_notices", "upsellio_seed_cities_admin_notice");

function upsellio_get_seed_url($force = false)
{
    $params = [
        "upsellio_seed_cities" => 1,
        "_upsellio_nonce" => wp_create_nonce("upsellio_seed_cities"),
    ];

    if ($force) {
        $params["force"] = 1;
    }

    return add_query_arg($params, admin_url("edit.php?post_type=miasto"));
}

