<?php
if (!defined("ABSPATH")) {
    exit;
}
?>
<footer style="padding:40px 0;border-top:1px solid #e6e6e1;">
  <div style="width:min(1100px,calc(100% - 40px));margin:0 auto;">
    <div style="font-family:Syne,sans-serif;font-size:22px;">Upsellio</div>
    <p style="margin-top:8px;color:#6f6f67;">Marketing · Strony WWW · SEO lokalne</p>
    <?php echo upsellio_get_footer_city_links_html(); ?>
    <div style="margin-top:22px;padding-top:14px;border-top:1px solid #e6e6e1;font-size:12px;color:#7c7c74;">
      © <?php echo esc_html(gmdate("Y")); ?> Upsellio / Sebastian Kelm. Wszelkie prawa zastrzezone.
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>

