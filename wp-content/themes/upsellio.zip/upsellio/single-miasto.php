<?php
if (!defined("ABSPATH")) {
    exit;
}

get_header();

while (have_posts()) :
    the_post();
    $postId = get_the_ID();
    $cityName = get_post_meta($postId, "_upsellio_city_name", true) ?: get_the_title();
    $voivodeship = get_post_meta($postId, "_upsellio_city_voivodeship", true) ?: "polska";
    $marketAngle = get_post_meta($postId, "_upsellio_city_market_angle", true) ?: "lokalne firmy";
    $serviceFocus = get_post_meta($postId, "_upsellio_city_service_focus", true) ?: "marketing i strony WWW";
    $cta = get_post_meta($postId, "_upsellio_city_cta", true);
    $faq = get_post_meta($postId, "_upsellio_city_faq", true);
    if (!is_array($faq)) {
        $faq = [];
    }
    $related = upsellio_get_city_nearby_links(get_post_meta($postId, "_upsellio_city_slug", true), 6);
    ?>
    <style>
      .city-wrap{width:min(1100px,calc(100% - 40px));margin:0 auto}
      .city-hero{padding:72px 0 42px;border-bottom:1px solid #e6e6e1;background:#f8f8f6}
      .city-breadcrumbs{font-size:12px;color:#6e6e66;margin-bottom:14px}
      .city-h1{font-family:Syne,sans-serif;font-size:clamp(34px,5vw,56px);line-height:1.05;letter-spacing:-1px}
      .city-lead{margin-top:18px;font-size:18px;line-height:1.75;color:#3d3d38;max-width:860px}
      .city-meta{display:flex;gap:12px;flex-wrap:wrap;margin-top:20px}
      .city-pill{font-size:12px;border:1px solid #c9c9c3;border-radius:999px;padding:6px 12px;background:#fff}
      .city-main{padding:56px 0;display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:34px}
      .city-content{line-height:1.8;color:#262624}
      .city-content h2,.city-content h3{font-family:Syne,sans-serif;line-height:1.2;color:#111110}
      .city-content h2{font-size:32px;margin:0 0 16px}
      .city-content h3{font-size:23px;margin:28px 0 10px}
      .city-content p{margin:0 0 14px}
      .city-content ul{margin:0 0 16px 20px}
      .city-content li{margin:0 0 8px}
      .city-side-card{border:1px solid #e6e6e1;border-radius:16px;padding:22px;background:#fff;position:sticky;top:90px}
      .city-side-title{font-family:Syne,sans-serif;font-size:22px;margin-bottom:10px}
      .city-side-list{display:grid;gap:8px;margin-top:14px}
      .city-side-link{font-size:14px;color:#5f5f58}
      .city-side-link:hover{color:#1d9e75}
      .city-cta{margin-top:22px;padding:16px;border-radius:12px;background:#e8f8f2;border:1px solid #c3eddd}
      .city-cta strong{display:block;margin-bottom:8px}
      .city-btn{display:inline-flex;margin-top:12px;background:#1d9e75;color:#fff;padding:11px 16px;border-radius:10px}
      .city-faq{margin-top:42px;border-top:1px solid #e6e6e1;padding-top:28px}
      .city-faq-item + .city-faq-item{margin-top:16px}
      @media(max-width:960px){.city-main{grid-template-columns:1fr}.city-side-card{position:static}}
    </style>

    <section class="city-hero">
      <div class="city-wrap">
        <div class="city-breadcrumbs">
          <a href="<?php echo esc_url(home_url("/")); ?>">Strona glowna</a> / 
          <a href="<?php echo esc_url(home_url("/miasta/")); ?>">Miasta</a> / 
          <span><?php echo esc_html($cityName); ?></span>
        </div>
        <h1 class="city-h1">Marketing i strony WWW <?php echo esc_html($cityName); ?></h1>
        <p class="city-lead">
          Skuteczne pozyskiwanie klientow w miescie <?php echo esc_html($cityName); ?>:
          kampanie Meta i Google Ads, strony pod konwersje oraz wsparcie sprzedazy B2B i uslug.
        </p>
        <div class="city-meta">
          <span class="city-pill">Wojewodztwo: <?php echo esc_html($voivodeship); ?></span>
          <span class="city-pill">Specjalizacja: <?php echo esc_html($marketAngle); ?></span>
          <span class="city-pill">Model: <?php echo esc_html($serviceFocus); ?></span>
        </div>
      </div>
    </section>

    <section class="city-main city-wrap">
      <article class="city-content">
        <?php the_content(); ?>

        <?php if (!empty($faq)) : ?>
          <div class="city-faq">
            <h2>Lokalne FAQ - <?php echo esc_html($cityName); ?></h2>
            <?php foreach ($faq as $item) : ?>
              <div class="city-faq-item">
                <h3><?php echo esc_html($item["q"]); ?></h3>
                <p><?php echo esc_html($item["a"]); ?></p>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </article>

      <aside class="city-side-card">
        <div class="city-side-title">Obslugiwane tez w poblizu</div>
        <div class="city-side-list">
          <?php foreach ($related as $item) : ?>
            <a class="city-side-link" href="<?php echo esc_url($item["url"]); ?>">
              <?php echo esc_html("Marketing i strony WWW " . $item["name"]); ?>
            </a>
          <?php endforeach; ?>
        </div>
        <div class="city-cta">
          <strong><?php echo esc_html($cta ?: ("Umow rozmowe dla " . $cityName)); ?></strong>
          <a class="city-btn" href="<?php echo esc_url(home_url("/#kontakt")); ?>">Umow bezplatna rozmowe</a>
        </div>
      </aside>
    </section>
    <?php
endwhile;

get_footer();

